from extract_features import extract_features
import joblib

model = joblib.load("model.pkl")
file = "example.wav"

features = extract_features(file)
features = features.reshape(1, -1)
result = model.predict(features)

if result[0] == 1:
    print("✅ استرس تشخیص داده شد.")
else:
    print("👌 وضعیت عادی (بدون استرس).")